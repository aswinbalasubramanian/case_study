export class User {
    userName: string;
    firstName: string;
    lastName: string;
    password: string;
    isAdmin: boolean; 

    constructor() { }
}